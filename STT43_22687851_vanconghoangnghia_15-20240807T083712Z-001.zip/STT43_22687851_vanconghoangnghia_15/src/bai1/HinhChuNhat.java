package bai1;

public class HinhChuNhat {
	//khai bao thuoc tinh
	private double chieuDai;
	private double chieuRong;
	//dong goi
	public double getChieuDai() {
		return this.chieuDai;
	}
	public void setChieuDai(double cd) {
		if (cd>0) {
			this.chieuDai=cd;
		} else {
			System.err.println("Loi cd");
		}
	}
	public double getChieuRong() {
		return this.chieuRong;
	}
	public void setChieuRong(double cr) {
		if (cr>0) {
			this.chieuRong=cr;
		} else {
			System.err.println("Loi cr");
		}
	}
	public double getDienTich() {
		return getChieuDai()*getChieuRong();
	}
	public double getChuVi() {
		return (getChieuDai()+getChieuRong())*2;

	}
	//ham tao
	public HinhChuNhat() {};
	public HinhChuNhat(double cd, double cr) {
		if (cd>0) {
			this.chieuDai=cd;
		} else {
			System.err.println("Loi cd");
		}
		if (cr>0) {
			this.chieuRong=cr;
		} else {
			System.err.println("loi cr");
		}
	}
	//to String
	@Override
	public String toString() {
		String s="";
		s+=s.format("%10s|%10s|%10s|%10s", getChieuDai(),getChieuRong(),getDienTich(),getChuVi());
		return s;
	}
}
