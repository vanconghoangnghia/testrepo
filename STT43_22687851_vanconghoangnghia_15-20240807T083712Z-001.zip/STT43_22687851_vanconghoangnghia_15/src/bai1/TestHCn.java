package bai1;

public class TestHCn {

	public static void main(String[] args) {
		//khoi tao doi tuong hcn1
		HinhChuNhat hcn1 = new HinhChuNhat();
		//cc gia tri
		hcn1.setChieuDai(30);
		hcn1.setChieuRong(20);
		System.out.println("chieu dai la: "+hcn1.getChieuDai());
		System.out.println("chieu dai la: "+hcn1.getChieuRong());
		//in tu string
		System.out.println(hcn1);
		//doi so
		HinhChuNhat hcn2 = new HinhChuNhat(35, 10);
		System.out.println(hcn2);
	}

}
