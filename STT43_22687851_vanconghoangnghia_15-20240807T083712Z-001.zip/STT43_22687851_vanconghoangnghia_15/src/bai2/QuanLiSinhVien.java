package bai2;

public class QuanLiSinhVien {
	private int maSV;
	private String hoTen;
	private float diemLT;
	private float diemTH;
	
	public QuanLiSinhVien(int maSV. String hoTen, float diemLT, float diemTH) {
		this.maSV=maSV;
		this.hoTen=hoTen;
		
	}
	
			
			
}